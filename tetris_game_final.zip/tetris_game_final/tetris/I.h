#pragma once
#include "Shape.h"

class I : public Shape
{
public:
	I();
	~I();

		
};

