#pragma once
#include "Shape.h"
class J : public Shape
{
public:
	J();
	~J();
};

