#pragma once
#include "Shape.h"

class T : public Shape
{
public:
	T();
	~T();
};

