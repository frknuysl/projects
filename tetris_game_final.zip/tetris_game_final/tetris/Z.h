#pragma once
#include "Shape.h"

class Z : public Shape
{
public:
	Z();
	~Z();
};

