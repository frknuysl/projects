#pragma once
#include "Shape.h"

class L : public Shape
{
public:
	L();
	~L();
};

