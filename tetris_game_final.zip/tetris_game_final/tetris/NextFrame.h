#pragma once
class NextFrame
{
public:
	NextFrame();
	~NextFrame();
};

