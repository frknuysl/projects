#pragma once
#include "Shape.h"

class O : public Shape
{
public:
	O();
	~O();
};

