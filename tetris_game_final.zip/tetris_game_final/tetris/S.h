#pragma once
#include "Shape.h"

class S : public Shape
{
public:
	S();
	~S();
};

