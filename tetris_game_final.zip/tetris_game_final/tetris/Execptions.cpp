#include "Execptions.h"



Execptions::Execptions()
{
}


Execptions::~Execptions()
{
}
